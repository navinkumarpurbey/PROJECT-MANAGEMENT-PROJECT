<!-- Main page banner  -->
</br>
<div class="container">
    <div class="account-type-title">
        <h2>Account Type</h2>
    </div>
    <div class="banner">
        <ul class="image-list">
            <li class="image-container">
                <a href="./usersignin.php">
                    <img src="./images/User-Trader/Users.png" alt="banner" class="User">
                    <h1>USER</h1>
                </a>
            </li>
            <li class="gap"></li>
            <li class="image-container">
                <a href="./tradersignin.php">
                    <img src=" ./images/User-Trader/Traders.png" alt="banner" class="Trader">
                    <h1>TRADER</h1>
                </a>
            </li>
        </ul>
    </div>
</div>