<div id="myOverlay" class="overlay">
    <span class="closebtn" onclick="closeSearch()" title="Close Overlay">×</span>
    <div class="overlay-content">
        <form action="products.php" method='GET'>
            <input type="text" placeholder="Search.." name="search">
            <button type="submit"><i class='bx bx-search-alt'></i></button>
        </form>
    </div>
</div>